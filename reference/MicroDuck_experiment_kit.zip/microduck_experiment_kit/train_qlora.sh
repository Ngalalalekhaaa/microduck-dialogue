#!/usr/bin/env bash
# ms-swift 4.1.3 argument names, Transformers 5.4.0 baseline.
# Run only after actual processor/label audit and isolated-environment smoke test.
set -euo pipefail
: "${MODEL:?Set MODEL to the fixed local Qwen3.5-2B directory}"
: "${TRAIN:?Set TRAIN to audited train.jsonl}"
: "${VAL:?Set VAL to audited val.jsonl}"
OUT="${OUT:-outputs/microduck_qlora}"
MAX_LENGTH="${MAX_LENGTH:-1024}"
LR="${LR:-1e-4}"
RANK="${RANK:-8}"
EPOCHS="${EPOCHS:-2}"
MAX_STEPS="${MAX_STEPS:--1}"
ACCUM="${ACCUM:-16}"
SEED="${SEED:-17}"
SAVE_TOTAL_LIMIT="${SAVE_TOTAL_LIMIT:-8}"
[[ -d "$MODEL" && -f "$TRAIN" && -f "$VAL" ]] || { echo "Model directory or JSONL inputs missing" >&2; exit 1; }
command -v swift >/dev/null || { echo "Activate the isolated ms-swift environment" >&2; exit 1; }
mkdir -p "$OUT"
python -m pip freeze > "$OUT/environment.txt"
python - "$MODEL" "$TRAIN" "$VAL" "$OUT" <<'PY'
import hashlib, json, sys
from pathlib import Path
model, train, val, out = map(Path, sys.argv[1:])
manifest = {"model": str(model.resolve()), "training_status": "launch_requested_not_verified"}
for name, p in [("train", train), ("val", val)]:
    raw = p.read_bytes()
    manifest[name] = {"path": str(p.resolve()), "sha256": hashlib.sha256(raw).hexdigest(), "lines": len([x for x in raw.splitlines() if x.strip()])}
(out / "input_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
PY
export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}"
export PYTORCH_CUDA_ALLOC_CONF="${PYTORCH_CUDA_ALLOC_CONF:-expandable_segments:True}"
# For image experiments, set IMAGE_MAX_TOKEN_NUM separately and audit actual
# expanded visual-token lengths. The initial experiment should be text-only.
swift sft \
  --model "$MODEL" \
  --tuner_type lora --tuner_backend peft \
  --quant_method bnb --quant_bits 4 \
  --bnb_4bit_quant_type nf4 --bnb_4bit_use_double_quant true \
  --bnb_4bit_compute_dtype bfloat16 --torch_dtype bfloat16 \
  --freeze_llm false --freeze_vit true --freeze_aligner true \
  --target_modules all-linear --lora_rank "$RANK" --lora_alpha 16 --lora_dropout 0.05 \
  --dataset "$TRAIN" --val_dataset "$VAL" --split_dataset_ratio 0 \
  --max_length "$MAX_LENGTH" --truncation_strategy delete \
  --loss_scale last_round+ignore_empty_think --add_non_thinking_prefix true \
  --gradient_checkpointing true --gradient_checkpointing_kwargs '{"use_reentrant": false}' \
  --per_device_train_batch_size 1 --per_device_eval_batch_size 1 \
  --gradient_accumulation_steps "$ACCUM" \
  --learning_rate "$LR" --num_train_epochs "$EPOCHS" --max_steps "$MAX_STEPS" \
  --warmup_ratio 0.05 --weight_decay 0.01 --max_grad_norm 1.0 \
  --lr_scheduler_type cosine --optim adamw_torch \
  --packing false --padding_free false \
  --eval_strategy steps --eval_steps 50 --save_strategy steps --save_steps 50 \
  --save_total_limit "$SAVE_TOTAL_LIMIT" --logging_steps 5 --report_to none \
  --dataloader_num_workers 0 --dataset_num_proc 1 \
  --seed "$SEED" --data_seed "$SEED" \
  --output_dir "$OUT"
