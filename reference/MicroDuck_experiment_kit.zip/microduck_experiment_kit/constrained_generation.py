"""Optional XGrammar integration for an already-loaded HuggingFace model.
Not GPU-tested here. Use the project processor and non-thinking chat template.
"""
import json
from pathlib import Path


def compile_plan_grammar(model, tokenizer, schema_path: str):
    import xgrammar as xgr
    schema = json.loads(Path(schema_path).read_text(encoding="utf-8"))
    vocab_size = model.get_output_embeddings().weight.shape[0]
    info = xgr.TokenizerInfo.from_huggingface(tokenizer, vocab_size=vocab_size)
    compiler = xgr.GrammarCompiler(info)
    return compiler.compile_json_schema(json.dumps(schema, ensure_ascii=False))


def generate_plan(model, model_inputs, compiled_grammar, max_new_tokens: int = 768):
    from xgrammar.contrib.hf import LogitsProcessor
    # State is per generation call. Reuse compiled grammar, NOT this processor.
    processor = LogitsProcessor(compiled_grammar)
    return model.generate(
        **model_inputs,
        do_sample=False,
        repetition_penalty=1.0,
        max_new_tokens=max_new_tokens,
        logits_processor=[processor],
    )
