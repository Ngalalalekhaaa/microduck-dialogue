# 数据与评估合同（建议版，非原项目协议）

## 数据量

先建1200条共同能力域训练集；扩充到2400条时，前1200条保持为其子集。
验证集240条，其中96条为固定筛查子集；盲测480条，最后才使用。
这些都是“决策边界样本”数量，不是视频帧数、JSON token数或完整机器人轨迹数量。

|类别|1200条训练集|2400条训练集|
|---|---:|---:|
|单目标|300|600|
|2至6目标|500（每种长度100）|1000（每种长度200）|
|追加/替换/取消/暂停/恢复等状态交互|180|360|
|聊天、能力问答、无需动作的回合|120|240|
|不支持、歧义、否定等边界|100|200|

1200条必须可由现有小头完整表达。扩充数据可加入任意协议允许参数，但旧小头只在可表达子集上比较；另报覆盖率。模板生成不是数据充分性的保证。

## 原始记录 JSONL

每行建议包含：

```json
{
  "id": "unique-id",
  "split": "train",
  "bucket": "multi_3",
  "family_id": "paraphrase-and-counterfactual-family",
  "episode_id": null,
  "plan_signature": "kick:red|kick:yellow|turn:left:360",
  "source_kind": "synthetic_semantic",
  "requires_pixels": false,
  "messages": [
    {"role":"system", "content":"完整且与部署一致的规划提示、真实能力与目标schema"},
    {"role":"user", "content":"可信状态与历史……\n当前用户指令……"}
  ],
  "gold": {
    "decision":"replace",
    "goals":[
      {"type":"kick","target":{"category":"ball","attributes":[{"name":"color","value":"red"}],"entity_id":null}},
      {"type":"kick","target":{"category":"ball","attributes":[{"name":"color","value":"yellow"}],"entity_id":null}},
      {"type":"turn","direction":"left","angle_deg":360}
    ]
  },
  "gold_alternatives": [],
  "images": []
}
```

这是格式说明；省略号必须替换为真实输入，不能直接作为正式训练数据。图像样本的messages使用`<image>`占位，images用绝对路径，顺序一致。metadata不得进入模型输入。source_kind区分synthetic_semantic、simulation_observed、real_observed；不能把合成状态记成实际执行。

## 划分规则

同一原始片段、改写家庭、配对反事实家庭不跨集合；视觉评估另检查场景布局、相机条件和图片哈希。
新表达测试允许计划本身在训练出现，但措辞家庭未见；新组合测试要求计划签名未见，组成它的原子技能已见。两个测试不要混为一个指标。
微调/选提示只用训练与验证；盲测不得用于补错后继续宣称“未见测试”。

## 采集方式

1. 从协议及合法任务状态生成正确结构化计划。
2. 在已分配的集合内生成最多约3种语言表达，补充人工自然表达。
3. 单独审核语言与原计划是否一致，尤其否定、指代、追加和数字。
4. 对需要真实状态的任务运行仿真，在新指令、用户修改、技能结果等决策边界记录。
5. 所有标签先过原协议和能力检查；小头标签再做编码—解码无损往返。
6. 对所有危险边界、新盲测及抽样普通样本人工审查。

不需要每一种语言改写重新跑完整物理过程；但共享轨迹的语言样本属于同组，不能分散到测试。
重复增加同一计划和同一问候前缀不算扩大语义覆盖。

## 推理输出记录

```json
{
  "id":"unique-id",
  "raw_output":"{\"decision\":\"respond\",\"goals\":[]}",
  "protocol_valid":true,
  "latency_s":1.5,
  "source":"model_raw"
}
```

protocol_valid必须来自原项目校验器；没有校验就省略，不能用本包的envelope_valid代替。
保存第一次输出；修复/重试另记。规则教师兜底不可写成模型成功。输出失败、超时和缺失都计入总分母。

## 衡量项目

JSON解析、外部协议/状态合法、decision、完整语义计划、单步目标、颜色/数字/方向、顺序、长度、误启动、虚假完成分别记录。
不把reply文本相似度加入计划严格匹配。合法的等价实体绑定应提前写在gold_alternatives；不得按预测结果临时宽松解释。
每个长度1..6、冷启动/问候后/执行中、见过组合/未见组合分开报告。训练后的模型用自由解码，不能以teacher forcing精度代替。

建议路线筛选门槛：协议合法率≥99%，整体完整计划≥95%，3至6步子集≥90%，边界测试未发现误启动。仅作原型门槛，不代表实机安全认证。
