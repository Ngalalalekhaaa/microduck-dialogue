"""Candidate H2 building block, not a drop-in replacement for the project head.

Pass ONLY input-side hidden states as memory. Preserve original goal/parameter
embeddings, labels, EOS and output classifiers for a controlled comparison.
"""
from __future__ import annotations
import torch
from torch import Tensor, nn


class MemoryGRUCell(nn.Module):
    def __init__(self, previous_goal_dim: int, memory_dim: int = 2048, hidden_dim: int = 128):
        super().__init__()
        self.hidden_dim = hidden_dim
        self.key = nn.Linear(memory_dim, hidden_dim, bias=False)
        self.value = nn.Linear(memory_dim, hidden_dim, bias=False)
        self.query = nn.Linear(hidden_dim, hidden_dim, bias=False)
        self.energy = nn.Linear(hidden_dim, 1, bias=False)
        self.cell = nn.GRUCell(previous_goal_dim + hidden_dim, hidden_dim)

    def prepare_memory(self, memory: Tensor, padding_mask: Tensor) -> tuple[Tensor, Tensor, Tensor]:
        """memory: [B,T,2048]; padding_mask: [B,T], True for padding."""
        if memory.ndim != 3 or padding_mask.shape != memory.shape[:2]:
            raise ValueError("Expected [B,T,D] memory and [B,T] padding mask")
        if padding_mask.dtype != torch.bool:
            raise TypeError("padding_mask must be bool")
        if bool(padding_mask.all(dim=1).any()):
            raise ValueError("Every sample needs at least one non-padding input position")
        return self.key(memory), self.value(memory), padding_mask

    def forward(self, previous_goal: Tensor, hidden: Tensor,
                prepared: tuple[Tensor, Tensor, Tensor]) -> tuple[Tensor, Tensor]:
        keys, values, padding_mask = prepared
        q = self.query(hidden).unsqueeze(1)
        scores = self.energy(torch.tanh(keys + q)).squeeze(-1)
        scores = scores.masked_fill(padding_mask, float("-inf"))
        weights = torch.softmax(scores.float(), dim=-1).to(values.dtype)
        context = torch.bmm(weights.unsqueeze(1), values).squeeze(1)
        return self.cell(torch.cat((previous_goal, context), dim=-1), hidden), weights


def self_test() -> None:
    torch.manual_seed(17)
    cell = MemoryGRUCell(32)
    memory = torch.randn(2, 10, 2048)
    mask = torch.zeros(2, 10, dtype=torch.bool)
    mask[1, -3:] = True
    prepared = cell.prepare_memory(memory, mask)
    h = torch.zeros(2, 128)
    for _ in range(7):  # up to 6 goals + EOS; classifiers remain in the host head
        h, a = cell(torch.randn(2, 32), h, prepared)
    h.square().mean().backward()
    assert torch.allclose(a.sum(-1), torch.ones(2), atol=1e-5)
    assert torch.equal(a[1, -3:], torch.zeros(3))
    assert cell.key.weight.grad is not None
    assert all(torch.isfinite(p.grad).all() for p in cell.parameters() if p.grad is not None)
    print("CPU forward/backward and padding-mask self-test passed. No model accuracy measured.")

if __name__ == "__main__":
    self_test()
