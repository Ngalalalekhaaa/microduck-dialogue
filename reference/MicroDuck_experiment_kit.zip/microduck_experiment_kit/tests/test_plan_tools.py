import json
import tempfile
import unittest
from pathlib import Path
from plan_tools import strict_json, plan, derive_schema, export_sft, score

class Tests(unittest.TestCase):
    def test_duplicate_keys(self):
        with self.assertRaises(ValueError): strict_json('{"a":1,"a":2}')
        with self.assertRaises(ValueError): strict_json('{"a":NaN}')
    def test_envelope(self):
        with self.assertRaises(ValueError): plan({"decision":"replace","goals":[]})
        with self.assertRaises(ValueError): plan({"decision":"respond","goals":[{}]})
    def test_order_is_not_discarded(self):
        a={"type":"turn","direction":"left","angle_deg":90}
        b={"type":"perform","action":"nod","repeat":1}
        g=[{"id":"a","gold":{"decision":"replace","goals":[a,b]}}]
        p=[{"id":"a","raw_output":json.dumps({"decision":"replace","goals":[b,a]})}]
        self.assertEqual(score(g,p)["counts"]["semantic_exact"],0)
    def test_missing_prediction_counts(self):
        g=[{"id":"a","gold":{"decision":"respond","goals":[]}}]
        self.assertEqual(score(g,[])["counts"]["missing_prediction"],1)
    def test_export_no_metadata(self):
        r={"id":"a","split":"train","gold":{"decision":"respond","goals":[]},"family_id":"do-not-leak","messages":[{"role":"user","content":"你好"}]}
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/"sft.jsonl"; export_sft([r],p)
            obj=json.loads(p.read_text()); self.assertNotIn("family_id",obj)
            self.assertEqual(obj["messages"][-1]["role"],"assistant")
    def test_schema(self):
        from jsonschema import Draft7Validator
        s=derive_schema({"properties":{"decision":{"type":"string"},"goals":{"type":"array","items":{"type":"object"}}}})
        Draft7Validator.check_schema(s)
        validator=Draft7Validator(s)
        self.assertFalse(list(validator.iter_errors({"decision":"replace","goals":[{}]})))
        self.assertTrue(list(validator.iter_errors({"decision":"replace","goals":[]})))
        self.assertTrue(list(validator.iter_errors({"decision":"respond","goals":[{}]})))

if __name__ == '__main__': unittest.main()
