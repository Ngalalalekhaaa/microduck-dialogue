#!/usr/bin/env python3
"""Offline schema derivation, SFT export and semantic scoring. No robot I/O.

Requires Python >=3.10. A valid production protocol result must be supplied by
its existing validator; this script does not emulate physical/state validation.
"""
from __future__ import annotations
import argparse
import copy
import json
import math
from collections import defaultdict
from pathlib import Path
from typing import Any

DECISIONS = {"respond", "clarify", "decline", "replace", "append", "cancel", "pause", "resume"}
ACTION_DECISIONS = {"replace", "append"}


def _pairs(items):
    out = {}
    for k, v in items:
        if k in out:
            raise ValueError(f"Duplicate JSON key: {k}")
        out[k] = v
    return out


def _constant(value):
    raise ValueError(f"Non-JSON numeric constant: {value}")


def strict_json(text: str) -> Any:
    return json.loads(text, object_pairs_hook=_pairs, parse_constant=_constant)


def read_jsonl(path: str | Path) -> list[dict]:
    rows = []
    for n, line in enumerate(Path(path).read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        try:
            row = strict_json(line)
            if not isinstance(row, dict):
                raise ValueError("row must be an object")
        except (ValueError, TypeError) as exc:
            raise ValueError(f"{path}:{n}: {exc}") from exc
        rows.append(row)
    return rows


def plan(obj: dict) -> dict:
    """Read either the proposed planner output or the known full wrapper.

    This validates only the top-level planning envelope, NOT goals' fields,
    current capabilities or execution state.
    """
    if not isinstance(obj, dict):
        raise ValueError("Output must be an object")
    allowed = {"decision", "goals", "schema_version", "reply"}
    if not set(obj).issubset(allowed):
        raise ValueError("Unknown top-level keys")
    d, goals = obj.get("decision"), obj.get("goals")
    if d not in DECISIONS or not isinstance(goals, list):
        raise ValueError("Missing/invalid decision or goals")
    if d in ACTION_DECISIONS:
        if not 1 <= len(goals) <= 6:
            raise ValueError("replace/append need 1..6 goals")
    elif goals:
        raise ValueError("Non-action decisions require empty goals")
    if any(not isinstance(g, dict) for g in goals):
        raise ValueError("Each goal must be an object")
    return {"decision": d, "goals": copy.deepcopy(goals)}


def unique_index(rows: list[dict]) -> dict[str, dict]:
    result = {}
    for row in rows:
        sid = row.get("id")
        if not isinstance(sid, str) or not sid or sid in result:
            raise ValueError(f"Missing/duplicate string id: {sid!r}")
        result[sid] = row
    return result


def canonical(obj: Any) -> Any:
    """JSON object key order is irrelevant; goal/attribute array order is not.

    Equivalent entity bindings must be enumerated in gold_alternatives, rather
    than inferred or 'repaired' based on the correct answer at scoring time.
    """
    if isinstance(obj, bool):
        return ("bool", obj)
    if isinstance(obj, (int, float)):
        return ("number", obj)
    if isinstance(obj, dict):
        return ("object", tuple(sorted((k, canonical(v)) for k, v in obj.items())))
    if isinstance(obj, list):
        return ("array", tuple(canonical(v) for v in obj))
    return (type(obj).__name__, obj)


def derive_schema(source: dict) -> dict:
    props = source.get("properties", {})
    if not all(k in props for k in ["decision", "goals"]):
        raise ValueError("Expected exported schema with root properties decision/goals. Resolve its root $ref first.")
    result = {
        "$schema": source.get("$schema", "http://json-schema.org/draft-07/schema#"),
        "title": "Microduck proposed planner-only envelope",
        "type": "object", "additionalProperties": False,
        "required": ["decision", "goals"],
        "properties": {k: copy.deepcopy(props[k]) for k in ("decision", "goals")},
        "anyOf": [
            {"properties": {"decision": {"enum": sorted(ACTION_DECISIONS)}, "goals": {"minItems": 1, "maxItems": 6}}},
            {"properties": {"decision": {"enum": sorted(DECISIONS - ACTION_DECISIONS)}, "goals": {"maxItems": 0}}}
        ]
    }
    for key in ("$defs", "definitions"):
        if key in source:
            result[key] = copy.deepcopy(source[key])
    # Original root allOf/if/state checks are deliberately not silently copied:
    # they may reference reply/schema_version. Re-run the production validator.
    return result


def export_sft(rows: list[dict], output: Path) -> int:
    unique_index(rows)
    exported = []
    for row in rows:
        if row.get("split") not in {"train", "val"}:
            raise ValueError(f"{row['id']}: export only explicitly tagged train/val records")
        messages = copy.deepcopy(row.get("messages"))
        if not isinstance(messages, list) or not messages or messages[-1].get("role") != "user":
            raise ValueError(f"{row['id']}: messages must be exact inference input ending with current user event")
        if any(not isinstance(m.get("content"), str) for m in messages):
            raise ValueError("This exporter expects ms-swift string contents; use <image> plus images paths")
        answer = plan(row["gold"])
        messages.append({"role": "assistant", "content": json.dumps(answer, ensure_ascii=False, separators=(",", ":"))})
        item = {"messages": messages}
        if "images" in row:
            paths = row["images"]
            if not isinstance(paths, list) or any(not isinstance(p, str) for p in paths):
                raise ValueError(f"{row['id']}: images must be path strings")
            n_tags = sum(m["content"].count("<image>") for m in messages[:-1])
            if n_tags != len(paths):
                raise ValueError(f"{row['id']}: image placeholders and files mismatch")
            for p in paths:
                if not Path(p).is_file():
                    raise ValueError(f"{row['id']}: image not found: {p}; use absolute paths")
            item["images"] = paths
        exported.append(item)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in exported), encoding="utf-8")
    return len(exported)


def percentile(vals: list[float], q: float) -> float | None:
    if not vals:
        return None
    vals = sorted(vals)
    pos = (len(vals) - 1) * q
    lo, hi = math.floor(pos), math.ceil(pos)
    return vals[lo] * (hi - pos) + vals[hi] * (pos - lo) if lo != hi else vals[lo]


def score(gold_rows: list[dict], predictions: list[dict]) -> dict:
    gold = unique_index(gold_rows)
    pred = unique_index(predictions)
    unknown = set(pred) - set(gold)
    if unknown:
        raise ValueError(f"Predictions contain unknown IDs: {sorted(unknown)[:5]}")
    counts = defaultdict(int)
    groups = defaultdict(lambda: {"n": 0, "semantic_exact": 0})
    latencies, details = [], []
    for sid, row in gold.items():
        expected = plan(row["gold"])
        alternatives = [expected] + [plan(v) for v in row.get("gold_alternatives", [])]
        p = pred.get(sid)
        counts["n"] += 1
        bucket = row.get("bucket", "unspecified")
        groups[bucket]["n"] += 1
        parsed = envelope = exact = False
        candidate = None
        if p is not None:
            try:
                obj = strict_json(p["raw_output"])
                parsed = True
                candidate = plan(obj)
                envelope = True
                exact = any(canonical(candidate) == canonical(a) for a in alternatives)
            except (ValueError, TypeError, KeyError):
                pass
            pv = p.get("protocol_valid")
            if isinstance(pv, bool):
                counts["protocol_checked"] += 1
                counts["protocol_valid"] += int(pv)
            latency = p.get("latency_s")
            if isinstance(latency, (int, float)) and not isinstance(latency, bool) and math.isfinite(latency) and latency >= 0:
                latencies.append(float(latency))
        else:
            counts["missing_prediction"] += 1
        counts["json_parseable"] += int(parsed)
        counts["envelope_valid"] += int(envelope)
        counts["semantic_exact"] += int(exact)
        groups[bucket]["semantic_exact"] += int(exact)
        if expected["decision"] not in ACTION_DECISIONS:
            counts["non_action_gold"] += 1
            counts["wrong_start"] += int(candidate is not None and candidate["decision"] in ACTION_DECISIONS)
        if expected["decision"] in ACTION_DECISIONS:
            counts["action_gold"] += 1
            counts["action_semantic_exact"] += int(exact)
        details.append({"id": sid, "semantic_exact": exact, "json_parseable": parsed, "envelope_valid": envelope})
    n = counts["n"]
    return {
        "warning": "Envelope validity is NOT protocol/state validity. Missing predictions count as incorrect. No robot completion is measured.",
        "counts": dict(counts),
        "semantic_exact_rate": counts["semantic_exact"] / n if n else None,
        "by_bucket": dict(groups),
        "latency_p50_s": percentile(latencies, .5),
        "latency_p95_s": percentile(latencies, .95),
        "details": details,
    }


def main():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest="command", required=True)
    s = sub.add_parser("derive-schema")
    s.add_argument("source")
    s.add_argument("output")
    s = sub.add_parser("export-sft")
    s.add_argument("records")
    s.add_argument("output")
    s = sub.add_parser("score")
    s.add_argument("records")
    s.add_argument("predictions")
    s.add_argument("output")
    args = p.parse_args()
    if args.command == "derive-schema":
        result = derive_schema(strict_json(Path(args.source).read_text(encoding="utf-8")))
        Path(args.output).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
        print("Schema derived. Check references and original validator before using it for constrained decoding.")
    elif args.command == "export-sft":
        print(f"Exported {export_sft(read_jsonl(args.records), Path(args.output))} examples.")
        print("Next: audit full processor/template tokenization, labels and ZERO dropped/truncated records.")
    else:
        result = score(read_jsonl(args.records), read_jsonl(args.predictions))
        Path(args.output).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
        print(json.dumps({k: v for k, v in result.items() if k != "details"}, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
