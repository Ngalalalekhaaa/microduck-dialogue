# MicroDuck 分阶段实验工作包

这是根据《PROJECT_BRIEF_ZH.md》编写的实验设计和独立工具，不是对用户仓库的直接补丁。未取得源代码、模型权重或原始训练集，也未在RTX 4050 6 GB上训练或测出模型准确率。没有修改机器人底层策略或协议。

已在当前环境完成：plan_tools的6项单元测试；MemoryGRUCell的CPU前向、反向、mask检查；训练脚本的Bash语法检查。训练显存、Qwen/XGrammar适配和仓库接线仍须在用户环境验证。

## 文件

- `experiment_matrix.json`：P/H/Q实验编号和改动。
- `prompts/planner_contract_full.txt`：P1完整协议提示候选；`planner_contract.txt`：P2以后仅规划字段提示；`fewshot6.json`：6个固定示例。完整能力和目标Schema仍要宿主提供。
- `DATA_SPEC_ZH.md`：数据量、样本合同、分组切分和指标。
- `plan_tools.py`：严格JSON解析、规划包络检查、从已导出的原Schema生成候选规划Schema、SFT导出、离线评分。
- `constrained_generation.py`：XGrammar接入已有HF模型的示例。
- `memory_gru_cell.py`：H2交叉注意力GRU单元；保留原项目标签、参数头与EOS。
- `train_qlora.sh`：以ms-swift 4.1.3参数命名编写的QLoRA启动脚本。

## 推荐执行顺序

P0原基线 → P1提示 → P2只输出计划 → P3无损输入精简 → P4固定few-shot / P5约束解码。
每版先96条开发样本，前两名再240条；仅在优胜版上合并有效修改。P6去图只用于预先声明的不依赖像素任务，不能把看图指代变成猜测。

若提示方案已达到要求，不训练。否则用修正后的1200条共同能力域数据做H0原128维GRU、H1扩到256维、H2读取多位置memory的128维GRU。H3 Transformer属于可选，不是必做。

QLoRA依次为32至64条链路过拟合、1200条公平比较、2400条扩展、必要时真实视觉依赖任务。Q0纯文本烟雾测试不代表视觉训练已跑通；所有路线比较须使用同一个输入视图和能力域。

## 与原仓库的接线点

原报告列出的文件用于定位，而非声称其函数签名已知：

- 输入/输出适配：`toy_inputs.py`、`toy_protocol.py`、`toy_schema.py`。
- 提示与生成：`toy_vlm_prompt_compact.py`、`toy_vlm_backend.py`。
- 缓存和技能头：`toy_head_features.py`、`toy_selector_model.py`、`toy_selector_labels.py`。
- 训练和评估：`toy_selector_training.py`及现有测试入口。

要新增一个离线入口，输入数据集中的**同一份模型输入messages/images**，依次调用各后端并输出raw_output；禁用教师兜底。不必每条都跑MuJoCo。物理闭环留给最终候选。

不要给`toy.sh`增加不存在的命令行参数。原始基线可用报告已有命令：

```bash
cd /home/luckysir/Strands_Robots
./experiments/microduck_tasks/toy.sh --backend vlm --vlm-context compact --interactive
```

## 内外协议

P2的模型只生成`decision`与`goals`。goals内部保持原项目Schema。宿主填原schema_version，在计划通过校验且实际提交之后生成“已接受”回复。执行完成回复只能根据可信完成事件生成。

聊天、视觉问答仍需生成式回复分支，可复用同一基座；不是要求机器人所有回答变成模板。外部reply非空约束保持。

`derive-schema`只从原Schema导出规划字段并添加顶层约束，不代替原始状态检查。若原Schema根节点用$ref，先解析根引用；检查局部引用是否仍有效。不能根据这份报告自行猜move.limit等未展开字段。

```bash
python plan_tools.py derive-schema full_exported.schema.json planner.schema.json
python plan_tools.py export-sft train_records.jsonl train.jsonl
python plan_tools.py score dev_records.jsonl predictions.jsonl metrics.json
```

## H2具体约束

- 主干冻结，memory只来自输入，不含目标答案、未来反馈。
- 先仅让目标序列分支动态读取memory，decision分支维持原逻辑；另报提供正确decision时的诊断成绩。
- hidden=128，最多6目标加EOS；只有padding被mask。
- `prepare_memory`每个样本做一次，循环时重用，不能在各步重新跑整个Qwen。
- memory可先存当前指令token、必要历史/状态token及分段聚合的其余位置；必须记录准确的角色/位置映射和截断情况。Qwen是因果语言主干，较早位置不能看到后面的指令，不应当成双向编码器特征；保持输入排列固定。缓存键包括模型revision、量化设置、模板、原始输入及图像哈希。标准化统计只用训练集。
- 多位置缓存按BF16存。256×2048×2 bytes约1 MiB/样本，2400条约2.34 GiB，不含其他文件。不要默认保存全部长序列全部层。
- H1与H2参数量不同；输出参数量、缓存大小和耗时。若要归因于跨位置读取，应与接近参数量的单向量模型对照，不只与最小模型比。
- 训练仅按适用字段算损失；非动作回合不训练虚假目标；推理使用自回归预测并评估整个序列。

## QLoRA环境

使用独立环境，不覆盖当前能跑仿真的venv。保留原Torch/CUDA兼容组合；本脚本依据ms-swift 4.1.3接口，建议锁定transformers 5.4.0、bitsandbytes 0.49.2，再记录实际peft、accelerate、fla等版本。框架允许的依赖版本范围不等于本任务已完成兼容性验证。

首次运行前必须完成：

1. 打印量化后、训练准备后、LoRA注入后的dtype与可训练模块；只训练语言主干LoRA。
2. 使用真实模板/processor检查每条完整输入输出长度、图片展开长度和labels；输入与历史不计loss，只监督当前JSON。
3. 统计被删除和被截断样本，必须为0。脚本的delete只是框架参数，不允许静默丢样本后继续声称使用原数据量。
4. 检查训练与推理均为非思考模式；`use_cache=False`用于训练，不影响上线推理的正常缓存。
5. 显存压力测试包含最长序列、6目标与optimizer.step，而不只测试最短文本。

```bash
# 以下路径以原报告的仓库根目录为基准；工作包路径按实际放置位置改。
cd /home/luckysir/Strands_Robots
export MODEL="$PWD/.cache/microduck_head/model"
export TRAIN="/absolute/path/train32.jsonl"
export VAL="/absolute/path/train32.jsonl"
export OUT="$PWD/outputs/qlora_smoke"
export MAX_LENGTH=1024
export MAX_STEPS=100
export ACCUM=8
bash /absolute/path/microduck_experiment_kit/train_qlora.sh
```

以上同训练集评估只用于过拟合检查，不能报告为泛化。

正式训练：

```bash
export TRAIN="/absolute/path/train1200.jsonl"
export VAL="/absolute/path/val240.jsonl"
export OUT="$PWD/outputs/qlora1200"
export MAX_STEPS=-1
export EPOCHS=2
export ACCUM=16
export LR=1e-4
bash /absolute/path/microduck_experiment_kit/train_qlora.sh
```

用开发集比较`LR=5e-5`的同配置；不要同时更换rank、数据和提示。若扩到2400，先保持其余条件不变。推理使用同一个已固定基座、处理器、量化方式和模板，加载选中的checkpoint适配器，`enable_thinking=false`、贪心生成。

用工具在盲测外选择最佳checkpoint，不能只看eval_loss。脚本默认最多保留8个checkpoint，足以保留2400条×2轮、累积16、每50步保存配置下的6次定期保存；更长训练需提高SAVE_TOTAL_LIMIT或及时另存最佳适配器。训练后逐个做生成式开发集评估，不能只看eval_loss。脚本不会自动选择语义指标最好的模型。

## 6 GB不够时

先检查实际token长度、完整词表logits和dtype升精度，再检查不需要的视觉计算或可训练模块。gradient checkpointing已开启；batch已经为1。不要以继续提高梯度累积来解决单个样本OOM。确认兼容性后再尝试分块/融合交叉熵或仅适配后若干语言层，并将后者记为新实验。不能删除长任务答案来“解决”显存问题。

## 图像阶段

先增加约600至1000条确实需要图像的决策样本。每条有正确相机标签和时刻；场景成对变化，指令不变时目标标签应相应变化。当前报告只支持三色球，不能合成任意物体或同色多球能力并当作已具备。

先单图，冻结vision/aligner；在整个训练数据中保留至少一半文字/状态样本以减少退化。用相同图像与标签比较无图、仅实体、仅图像、图像+实体。没有信息的设置允许澄清，不要求猜测。

## 异步与闭环

最终至少50个独立任务条件×3场景种子；逐一检查预测语义与执行结果，报告规划正确条件下的执行成功率及整条任务成功率。不要把错误动作被执行成功算作成功。

推理不再暂停物理时间后，独立验证停止线程、取消后旧计划丢弃、过期观察、反馈乱序和超时。急停、保护与任务revision由宿主负责，不能依赖VLM及时回答。

## 参考接口（查阅记录，不代表本工作包已经在其上训练）

```text
https://swift.readthedocs.io/en/v4.1/BestPractices/Qwen3_5-Best-Practice.html
https://swift.readthedocs.io/en/v4.1/Instruction/Command-line-parameters.html
https://swift.readthedocs.io/en/v4.1/Customization/Custom-dataset.html
https://huggingface.co/docs/peft/developer_guides/quantization
https://github.com/mlc-ai/xgrammar/blob/main/docs/start/quick_start.md
https://arxiv.org/abs/1409.0473
https://arxiv.org/abs/2305.14314
```
